Cropped icon tiles

Each source image with a visible rectangular frame was split into individual
icons. Files are arranged as:
  <source folder>/<source image name without extension>/icon_001.jpg ... icon_050.jpg

Tile order is left-to-right, then top-to-bottom. The frame was included in the
crop, its edge was painted black, and dark neutral compression fringes were
removed. Unframed sheets are not included and were left unchanged. Original
sheets are also left unchanged.
