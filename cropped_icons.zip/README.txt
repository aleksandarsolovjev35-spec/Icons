Cropped icon tiles

Each source image with a visible rectangular frame was split into individual
icons. Files are arranged as:
  <source folder>/<source image name without extension>/icon_001.jpg ... icon_050.jpg

Tile order is left-to-right, then top-to-bottom. The frame was included in the
crop, and a 4-pixel band around each tile's edge was painted black. Unframed
sheets are not included and were left unchanged in the repository. Original
sheets are also left unchanged.
